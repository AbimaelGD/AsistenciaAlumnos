
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Web</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.3/css/bulma.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Material+Icons" rel="stylesheet">
    <script type="text/javascript" src="js/jquery-3.6.0.js"></script>

</head>

<body>
    <?php include 'views/header.php' ?>

    <div class="container">
        <?php include 'routing.php' ?>
    </div>
    <?php include 'views/footer.php' ?>

    <script src="https://kit.fontawesome.com/2a30af82cb.js" crossorigin="anonymous"></script>

</body>

</html>

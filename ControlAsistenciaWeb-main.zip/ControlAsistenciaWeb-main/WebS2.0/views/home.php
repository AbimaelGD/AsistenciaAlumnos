<br>
<div class="columns">
    <div class="column is-narrow">
        <div class="box" style="width: 200px;">
            <figure>
                <i class=" fas fa-2x fas fa-user-graduate"></i>
            </figure>
            <p class="title is-5">Agenda de Alumnos</p>
            <p class="subtitle">Mantenga el control de los alumnos de su clase</p>
        </div>
    </div>
    <div class="column">
        <div class="box">
            <figure class="">
                <i class="fas fa-2x fas fa-clipboard-list"></i>
            </figure>
            <p class="title is-5">Control de Asistencia</p>
            <p class="subtitle">Área alumnos</p>
            <p>Comparte la información con tus alumnos. Ellos son el centro
                de tu negocio. Haz que formen parte de su estructura.</p>
            <br>
            <p>A través de la agenda el profesor puede gestionar el registro de su
                control de asistencias.</p>
        </div>
    </div>
</div>
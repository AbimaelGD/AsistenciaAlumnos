<?php
session_start();

require 'controller/conn.php';

if (isset($_SESSION['user_id'])) {
    $records = $conn->prepare('SELECT ID,Usuario_Correo,Contraseña FROM usuarios WHERE ID = :id');
    $records->bindParam(':id', $_SESSION['user_id']);
    $records->execute();
    $results = $records->fetch(PDO::FETCH_ASSOC);

    $user = null;

    if (count($results) > 0) {
        $user = $results;
    }

?>
    <div class="field">
        <a href="?menu=registrar"> <button class="button has-background-dark has-text-white" name="action">Registrar</button></a>
    </div>
    <table class="table" style="width:60%">
        <thead>
            <tr>
                <th>Id</th>
                <th>Alumno</th>
                <th>Nombre</th>
                <th>Sexo</th>
                <th>Opciones</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <?php include 'controller/conexion.php';
                $datosalumnos = "SELECT * FROM alumnos";
                $Verdatos = mysqli_query($conexion, $datosalumnos);
                while ($row = mysqli_fetch_assoc($Verdatos)) { ?>
                    <td><?php echo $row["id"]; ?></td>
                    <td><?php echo $row["alumno"]; ?></td>
                    <td><?php echo $row["nombre"]; ?></td>
                    <td>
                        <?php if ($row["sexo"] == 'M') { ?>
                            <i class="material-icons prefix blue-text">male</i>
                            <?php } else {
                            if ($row["sexo"] == 'F') { ?>
                                <i class="material-icons prefix red-text">female</i>
                            <?php } else { ?>
                                <i class="material-icons prefix green-text">transgender</i>
                        <?php  }
                        }
                        ?>
                    </td>
                    <td>
                        <button type="submit" name="action">
                            <a href="?menu=deletealumno&idalumno=<?php echo $row['id'] ?>">
                                <span style="font-size: 2em; color: Black;"> <i class="fas fa-trash-alt"></i></span>

                            </a>
                        </button>
                        <button type="submit" name="action">
                            <a href="?menu=editalumno&idalumno=<?php echo $row['id'] ?>">
                                <span style="font-size: 2em; color: Black;"> <i class="fas fa-edit"></i></span>
                            </a>
                        </button>
                    </td>
            </tr>
        <?php }
                mysqli_free_result($Verdatos);
        ?>
        </tbody>
    </table>
<?php
} else { ?>
    <?php include 'error401.php' ?>
<?php    } ?>
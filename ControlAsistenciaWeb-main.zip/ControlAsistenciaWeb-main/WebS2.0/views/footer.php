<!-- Inicio del pie de la Página -->
<footer class="footer">
    <div class="content has-text-centered">
        <p>
            <strong>UAC FI</strong> | Desarrollo de Aplicaciones Web | PHP Ver 1.0
        </p>
    </div>
</footer>
<!-- Fin del pie de la Página -->
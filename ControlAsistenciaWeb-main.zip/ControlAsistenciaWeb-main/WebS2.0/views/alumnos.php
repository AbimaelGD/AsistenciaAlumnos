<?php
session_start();

require 'controller/conn.php';

if (isset($_SESSION['user_id'])) {
    $records = $conn->prepare('SELECT ID,Usuario_Correo,Contraseña FROM usuarios WHERE ID = :id');
    $records->bindParam(':id', $_SESSION['user_id']);
    $records->execute();
    $results = $records->fetch(PDO::FETCH_ASSOC);

    $user = null;

    if (count($results) > 0) {
        $user = $results;
    }

?>
    <div class="field is-horizontal">
        <div class="box box-radius">
            <form action="controller/asistencia.php" method="POST">
                <h3 class="title is-5">Lista de asistencia</h3>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Alumno</th>
                            <th>Nombre</th>
                            <th>Asistencia</th>
                        </tr>
                    </thead>
                    <tbody>

                        <tr>
                            <?php include 'controller/conexion.php';
                            $datosalumnos = "SELECT * FROM alumnos";
                            $Verdatos = mysqli_query($conexion, $datosalumnos);
                            while ($row = mysqli_fetch_assoc($Verdatos)) { ?>
                                <td><?php echo $row["id"]; ?></td>
                                <td><?php echo $row["alumno"]; ?></td>
                                <td><?php echo $row["nombre"]; ?></td>
                                <td>
                                    <label><input type="checkbox" name="check_lista[]" value="<?php echo $row["alumno"]; ?>"></label>
                                </td>
                        </tr>
                    <?php }
                            mysqli_free_result($Verdatos);
                    ?>
                    </tbody>
                    <p class="control">
                        <input class="button has-background-dark has-text-white" type="submit" value="Enviar datos">
                    </p>
                </table>
            </form>
        </div>
        <div class="tile is-parent ">
            <article class="tile is-child notification has-background-dark">
                <div class="content">

                </div>
            </article>
        </div>

        <div class="box">
            <h3 class="title is-5">Asistencia por dia</h3>
            <table class="table ">
                <thead class="">
                    <tr>
                        <th>Id</th>
                        <th>Alumno</th>
                        <th>Fecha</th>
                        <th>Opciones</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <?php include 'controller/conexion.php';
                        $datosalumnos = "SELECT * FROM asistencia";
                        $Verdatos = mysqli_query($conexion, $datosalumnos);
                        while ($row = mysqli_fetch_assoc($Verdatos)) { ?>
                            <td><?php echo $row["id_asistencia"]; ?></td>
                            <td><?php echo $row["alumno"]; ?></td>
                            <td><?php echo $row["fecha"]; ?></td>
                            <td>
                                <button type="submit" name="action">
                                    <a href="?menu=deleteasistencia&idalumno=<?php echo $row['id_asistencia'] ?>">
                                        <span style="font-size: 1em; color: Black;"> <i class="fas fa-trash-alt"></i></span></a>
                                </button>

                            </td>
                    </tr>
                <?php }
                        mysqli_free_result($Verdatos);
                ?>
                </tbody>
            </table>
        </div>
    </div>
<?php

} else {
    include 'error401.php';
}

?>
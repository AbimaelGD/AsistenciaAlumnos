<?php
session_start();

require 'controller/conn.php';

if (isset($_SESSION['user_id'])) {
    $records = $conn->prepare('SELECT ID,Usuario_Correo,Contraseña FROM usuarios WHERE ID = :id');
    $records->bindParam(':id', $_SESSION['user_id']);
    $records->execute();
    $results = $records->fetch(PDO::FETCH_ASSOC);

    $user = null;

    if (count($results) > 0) {
        $user = $results;
    }
?>

    <div class="hero-body">
        <article class="tile is-child notification is-dark">
            <?php if (!empty($user)) { ?>
                Bienvenido. <?= $user['Usuario_Correo']; ?>
                <br>Has iniciado sesion correctamente deseas
                <a href="controller/logout.php">
                    Cerrar sesion
                </a>
            <?php
            }
            ?>
        </article>
    </div>



<?php

} else {
?>
    <div class="columns is-mobile">
        <div class="column is-three-fifths is-offset-one-fifth">
            <div class="box">
                <figure>
                    <i class="fas fa-2x fas fa-address-card"></i>
                </figure>
                <form action="controller/validar.php" method="POST">
                    <div class="field">
                        <label class="label">Email</label>
                        <div class="control has-icons-left">
                            <input class="input" type="email" placeholder="Email input" name="correo">
                            <span class="icon is-small is-left">
                                <i class="fas fa-envelope"></i>
                            </span>
                            <span class="icon is-small is-right">
                            </span>
                        </div>
                    </div>
                    <div class="field">
                        <label class="label">Password</label>
                        <p class="control has-icons-left">
                            <input class="input" type="password" placeholder="Password" name="contraseña" pattern="[A-Za-z0-9_-]{1,8}">
                            <span class="icon is-small is-left">
                                <i class="fas fa-lock"></i>
                            </span>
                        </p>
                    </div>
                    <p class="control">
                        <button class="button is-medium has-background-dark has-text-white" name="login">Iniciar</button>
                    </p>
                </form>
            </div>
        </div>
    </div>
<?php
}

?>
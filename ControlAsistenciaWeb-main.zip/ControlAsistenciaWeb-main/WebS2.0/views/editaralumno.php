<?php
session_start();

require 'controller/conn.php';

if (isset($_SESSION['user_id'])) {
    $records = $conn->prepare('SELECT ID,Usuario_Correo,Contraseña FROM usuarios WHERE ID = :id');
    $records->bindParam(':id', $_SESSION['user_id']);
    $records->execute();
    $results = $records->fetch(PDO::FETCH_ASSOC);

    $user = null;

    if (count($results) > 0) {
        $user = $results;
    }

?>
    <form action="./controller/update.php" method="POST">
        <div class="field is-horizontal">
            <div class="field-label is-normal">
                <label class="label">Actualizar</label>
            </div>
            <div class="field-body">


                <input type="hidden" name="id" value="<?php echo $sqlAlumnos['id']  ?>">
                <div class="field">
                    <p class="control is-expanded has-icons-left">
                        <input type="text" class="input is-success" name=" alumno" placeholder="alumno" value="<?php echo $sqlAlumnos['alumno']  ?>">
                        <span class="icon is-small is-left">
                            <i class="fas fa-list-ol"></i>
                        </span>
                    </p>
                </div>
                <div class="field">
                    <p class="control is-expanded has-icons-left has-icons-right">
                        <input type="text" class="input is-success " name="nombre" placeholder="nombre" value="<?php echo $sqlAlumnos['nombre']  ?>">
                        <span class="icon is-small is-left">
                            <i class="fas fa-user"></i>
                        </span>

                    </p>
                </div>
                <div class="field">
                    <p class="control is-expanded has-icons-left has-icons-right">
                        <input type="text" class="input is-success" name="sexo" placeholder="sexo" value="<?php echo $sqlAlumnos['sexo']  ?>">
                        <span class="icon is-small is-left">
                            <i class="fas fa-genderless"></i>
                        </span>

                    </p>
                </div>
                <input type="submit" class="button has-background-dark has-text-white" value="Actualizar">


            </div>
        </div>
    </form>
    <br>
    <br><?php
    } else { ?>
    <?php include 'error401.php' ?>
<?php    } ?>
<?php
session_start();

require 'controller/conn.php';

if (isset($_SESSION['user_id'])) {
    $records = $conn->prepare('SELECT ID,Usuario_Correo,Contraseña FROM usuarios WHERE ID = :id');
    $records->bindParam(':id', $_SESSION['user_id']);
    $records->execute();
    $results = $records->fetch(PDO::FETCH_ASSOC);

    $user = null;

    if (count($results) > 0) {
        $user = $results;
    }

?>
    <form action="controller/registrar.php" method="POST">
        <div class="field is-horizontal">
            <div class="field-body">

                <div class="field">
                    <div class="control">
                        <input class="input" type="text" placeholder="Alumno" autofocus="" name="Alumno">
                    </div>
                </div>
                <div class="field">
                    <p class="control  has-icons-left">
                        <input class="input" type="text" placeholder="Nombre" autofocus="" name="Nombre">
                        <span class="icon is-small is-left">
                            <i class="fas fa-user"></i>
                        </span>
                    </p>
                </div>
                <div class="control">
                    <div class="select">
                        <select name="Sexo">
                            <option>Sexo</option>
                            <option>M</option>
                            <option>F</option>
                            <option>Otro</option>
                        </select>
                    </div>
                </div>
                <div class="field">

                </div>
                <div class="field">
                    <input type="submit" class="button has-background-dark has-text-white" value="Registrar">
                </div>

            </div>
        </div>
    </form>

<?php
} else { ?>
    <?php include 'error401.php' ?>
<?php    } ?>
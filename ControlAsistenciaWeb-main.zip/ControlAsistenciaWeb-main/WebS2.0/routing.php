<?php

$var_getMenu = isset($_GET['menu']) ? $_GET['menu'] : 'inicio';

switch ($var_getMenu) {
    case "1":
        require_once('./views/home.php');
        break;
    case "2":
        require_once('./views/login.php');
        break;
    case "3":
        require_once('./views/alumnos.php');
        break;
    case "4":
        require_once('./views/registroalumnos.php');
        break;
    case "5":
        require_once('./views/acercade.php');
        break;
    case "logout":
        $session_destroy = session_destroy();
        header("location: ./index.php?menu=home");
        break;
    case "deletealumno":
        $_idalumno = trim(filter_input(INPUT_GET, 'idalumno'));
        require_once('./controller/alumnos.php');
        $sqlAlumnos = alumnos::delete($_idalumno);
        header("location: ./index.php?menu=4");
        break;
    case "deleteasistencia":
        $_idalumno = trim(filter_input(INPUT_GET, 'idalumno'));
        require_once('./controller/alumnos.php');
        $sqlAlumnos = alumnos::deleteasistencia($_idalumno);
        header("location: ./index.php?menu=3");
        break;
    case "editalumno":
        $_idalumno = trim(filter_input(INPUT_GET, 'idalumno'));
        require_once('./controller/alumnos.php');
        $sqlAlumnos = alumnos::consultarAlumno($_idalumno);
        include_once './views/editaralumno.php';
        break;
    case "registrar":
        include_once './views/registraralumnos.php';
        break;
    default:
        require_once('./views/home.php');
}
?>
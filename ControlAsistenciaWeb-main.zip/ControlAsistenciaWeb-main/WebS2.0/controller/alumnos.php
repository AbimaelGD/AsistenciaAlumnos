<?php
    include 'conectaDB.php';
class alumnos {
    public $id;
    public $alumno;
    public $nombre;
    public $sexo;
    
    public function __construct($id, $alumno, $nombre, $sexo) {  
        $this->id = $id;
        $this->alumno = $alumno;
        $this->nombre = $nombre;
        $this->sexo = $sexo;
    }  
 
    public static function delete($_idalumno) {
        $mysqli = conectadb::dbmysql();
        $stmt = $mysqli->prepare('DELETE FROM alumnos WHERE id = ? ');
        $stmt->bind_param('i', $_idalumno);
        $stmt->execute();
        $resultado = $stmt->get_result();
        }

    public static function consultaralumno($_idalumno)
    {
        $mysqli = conectadb::dbmysql();
        $stmt = $mysqli->prepare('SELECT * FROM alumnos WHERE id = ?');
        $stmt->bind_param('i', $_idalumno);
        $stmt->execute();
        $resultado = $stmt->get_result();
        $fila = $resultado->fetch_array();
        return $fila;
    }
    public static function update($_alumno, $_nombre, $_sexo, $_id)
    {
        $mysqli = conectadb::dbmysql();
        $stmt = $mysqli->prepare('UPDATE alumnos SET alumno=?, nombre = ?, sexo = ? WHERE id = ?');
        $stmt->bind_param('sssi', $_alumno, $_nombre, $_sexo, $_id);
        $stmt->execute();
        $resultado = $stmt->get_result();
        $acceso = false;
        if ($stmt->affected_rows == 1) {
            $acceso = true;
        }
        $mysqli->close();
        return $acceso;
    }

    public static function registrar($_id,$_alumno,$_nombre,$_sexo){
        $mysqli = conectadb::dbmysql();
        $stmt = $mysqli->prepare('INSERT INTO alumnos(id, alumno, nombre, sexo) VALUES (?,?,?,?)');
        $stmt->bind_param('isss',$_id,$_alumno, $_nombre, $_sexo);
        $stmt->execute();
        $resultado = $stmt->get_result();
        $acceso = false;
        if ($stmt->affected_rows == 1) {
            $acceso = true;
        }
        $mysqli->close();
        return $acceso;

    }


    public static function asistencia($_id, $_alumno,$_fecha)
    {
        $mysqli = conectadb::dbmysql();
        $stmt = $mysqli->prepare('INSERT INTO asistencia(id_asistencia, alumno, fecha) VALUES (?,?,?)');
        $stmt->bind_param('iss', $_id, $_alumno, $_fecha);
        $stmt->execute();
        $resultado = $stmt->get_result();
        $acceso = false;
        if ($stmt->affected_rows == 1) {
            $acceso = true;
        }
        $mysqli->close();
        return $acceso;
    }

    public static function deleteasistencia($_idalumno)
    {
        $mysqli = conectadb::dbmysql();
        $stmt = $mysqli->prepare('DELETE FROM asistencia WHERE id_asistencia = ? ');
        $stmt->bind_param('i', $_idalumno);
        $stmt->execute();
        $resultado = $stmt->get_result();
    }


}

    
?>
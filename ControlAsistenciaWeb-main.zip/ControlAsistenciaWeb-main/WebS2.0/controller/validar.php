<?php
session_start();

if (isset($_SESSION['user_id'])) {
    header('Location: /Webs2.0');
}
require 'conn.php';

if (!empty($_POST['correo']) && !empty($_POST['contraseña'])) {
    $records = $conn->prepare('SELECT ID, Usuario_Correo,Contraseña FROM usuarios WHERE Usuario_Correo = :email');
    $records->bindParam(':email', $_POST['correo']);
    $records->execute();
    $results = $records->fetch(PDO::FETCH_ASSOC);

    $message = '';

    if (count($results) > 0 && password_verify($_POST['contraseña'], $results['Contraseña'])) {
        $_SESSION['user_id'] = $results['ID'];
        header("Location: /Webs2.0");
    } else {
        $message = 'Sorry, those credentials do not match';
    }
}


?>
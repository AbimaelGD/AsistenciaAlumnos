<?php
session_start();

session_unset();

session_destroy();

header('Location:/Webs2.0');
?>

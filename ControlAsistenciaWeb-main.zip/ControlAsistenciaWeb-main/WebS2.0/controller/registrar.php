<?php
if (filter_input_array(INPUT_POST)) {
    $_alumno = trim(filter_input(INPUT_POST, 'Alumno'));
    $_nombre = trim(filter_input(INPUT_POST, 'Nombre'));
    $_sexo = trim(filter_input(INPUT_POST, 'Sexo'));
    include_once '../controller/alumnos.php';
    $registrar = alumnos::registrar("",$_alumno,$_nombre,$_sexo);
    if ($registrar){
        header("location: ../index.php?menu=4");
        } else{
        echo 'Error, no se pudo registrar';   
        }
}
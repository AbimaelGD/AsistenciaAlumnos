<?php

if (!empty($_POST['check_lista'])) {
    // Contando el numero de input seleccionados "checked" checkboxes.
    $checked_contador = count($_POST['check_lista']);

    //echo "<p>Has seleccionado los siguientes ".$checked_contador." opcione(s):</p> <br/>";
    // Bucle para almacenar y visualizar valores activados checkbox.
    foreach ($_POST['check_lista'] as $seleccion) {
        $_alumno = $seleccion;
        $_fecha=date('Y-m-d');
        include_once '../controller/alumnos.php';
        
        $registrar = alumnos::asistencia("", $_alumno, $_fecha);
        if ($registrar) {
            header("location: ../index.php?menu=3");
        } else {
            echo 'Error, no se pudo registrar';
        }
    }
} else {
    echo "<p><b>Por favor seleccione al menos una opción.</b></p>";
}
